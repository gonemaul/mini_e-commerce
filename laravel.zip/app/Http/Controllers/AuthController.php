<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLogin(){
        return view('auth.login')->with([
            'title' => 'Login',
        ]);
    }
    public function showRegister(){
        return view('auth.register')->with([
            'title' => 'Register',
        ]);
    }

    public function login(Request $request){
        // return $request;
        $validatedData = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8|max:16',
        ]);

        if (Auth::attempt($validatedData)) {
            $request->session()->regenerate();
 
            return redirect()->intended('/');
        }

        return back()->with('loginError', 'The provided credentials do not match our records.')->onlyInput('email');
        // return back()->withErrors([
        //     'error' => 'The provided credentials do not match our records!',
        // ])->onlyInput('email');
    }

    public function register(Request $request){
        $validatedData = $request->validate([
            'username' => 'required|min:6|max:20|unique:users',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8|max:16',
        ]);

        $validatedData['is_admin'] = true;
        $validatedData['name'] = $request['username'];
        User::Create($validatedData);

        if (Auth::attempt($validatedData)) {
            $request->session()->regenerate();
 
            return redirect()->intended('/');
        }
        
        // return dd($request);
    }

    public function logout(Request $request){
        Auth::logout();
 
        $request->session()->invalidate();
    
        $request->session()->regenerateToken();
    
        return redirect('login');
    }

    public function register_api(Request $request){
        $validatedData = $request->validate([
            'username' => 'required|min:6|max:20|unique:users',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8|max:16',
        ]);

        if(!$validatedData){
            return response()->json([
               'status' => 'error',
               'message' => 'data not valid',
                'data' => $validatedData,
            ]);
        }
        $validatedData['name'] = $request->username;
        $user = User::create($validatedData);

        $token = $user->createToken('authToken')->plainTextToken;
        return response()->json([
            'status' => 'success',
            'account' => $user,
            'token' => $token
        ]);
    }
    public function login_api(Request $request){
        // return 'oken';
        $validatedData = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8|max:16',
        ]);

        if (Auth::attempt($validatedData)) {
            // $request->session()->regenerate();
            

            return response()->json([
                'status' => 'success',
                'token' => Auth::token(),
                'account' => $validatedData 
            ]);
        }
    }
}
