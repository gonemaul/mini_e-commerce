<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function listUsers() {
        return view('users.index')->with([
            'title' => 'Users List',
            'data' => User::all(),
        ]);
    }

    public function adminProfile(){
        return view('users.admin_profile')->with([
            'title' => 'Admin Profile',
            'data' => Auth::user()
        ]);
    }

    public function adminChangeProfile(Request $request)
    {
        $user = User::findOrFail($request->id);
    
        // Validasi input
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'username' => 'required|string|min:6|max:20',
            'email' => 'required|string|email|max:255',
            'profilePhoto' => 'image|file|max:1024',
        ]);

        if ($request->file('profilePhoto')){
            $validatedData['profile_image'] = $request->file('profilePhoto')->store('profile_image');
        }

        $validatedData['name'] = Str::title($request->name);

        $user->update($validatedData);
        return redirect()->route('home')->with('success', 'profile updated');
    }

    public function adminChangePassword(Request $request){
        $user = Auth::user();
        return $user;
        // $request->validate([
        //     'old_password' => 'required|string',
        //     'new_password' => 'required|string|min:8|confirmed',
        // ]);

        // if (!Hash::check($request->old_password, $user->password)) {
        //     return back()->withErrors(['old_password' => 'Password old is invalid']);
        // }

        // $user->password = Hash::make($request->new_password);
        // // $user->save();

        // return redirect()->route('home')->with('success', 'Password berhasil diubah');
    }
    
}
