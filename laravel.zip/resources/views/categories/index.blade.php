@extends('layouts.main')

@section('content')
<div class="content-wrapper">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between mb-3">
                <h4 class="card-title">Categories List</h4>
                <a class="btn btn-inverse-primary btn-icon-text py-auto text-center" href="/categories/create" style="font-size:1rem;font-weight:500"><i class="text-center mdi mdi-plus"></i> Add Category</a>
            </div>
            <div class="table-responsive">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th class="text-center" style="font-weight:600;"> # </th>
                    <th class="text-center" style="font-weight:600;"> Category Name </th>
                    <th class="text-center" style="font-weight:600;"> Action </th>
                    {{-- <th class="text-center" style="font-weight:600;"> Username </th>
                    <th class="text-center" style="font-weight:600;"> Email </th>
                    <th class="text-center" style="font-weight:600;"> Status </th> --}}
                  </tr>
                </thead>
                <tbody>
                  @foreach ($data as $item)  
                    <tr>
                      <td class="text-center"> {{ $loop->iteration}} </td> 
                      <td> {{ $item->category_name }} </td> 
                      <td class="justify-content-center d-flex">
                            <a href="/categories/{{ $item->id }}/edit" class="bg-warning badge" style="margin-right: 0.5rem;color:white;font-size:1rem"><i class="mdi mdi-pencil"></i> Edit</a>
                            <form action="/categories/{{ $item->id }}" method="post">
                              @method('delete')
                              @csrf
                              <button type="submit" class="btn btn-danger badge" style="color:white;font-size:1rem"><i class="mdi mdi-delete"></i> Delete</button>
                            </form>
                      </td>
                      {{-- <td class="text-center"> <label class="badge badge-success">Active</label> </td> --}}
                    </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
</div>
@endsection