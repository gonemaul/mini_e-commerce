@extends('layouts.main')

@section('content')
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="{{ asset('assets/js/file-upload.js') }}"></script>
    <div class="content-wrapper">
        @if (url()->current() == Route('adminProfile'))
            <div class="row px-4 py-4" style="background-color: #191c24;border-radius:0.5rem">
                <div class="col-md-6 ps-3 text-center">
                    <h4 class="align-center">General Account</h4>
                </div>
                <div class="col md-6 ps-3 ">
                    <form action="{{ Route('adminChangeProfile') }}" method="post"  enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="id" value="{{ $data->id }}">
                        <div class="form-group">
                            <div class="mb-2">
                                <span>Profile Photo</span>
                            </div>
                            <div class="profileImg" style="margin-left: 1rem">
                                <img class="img-preview rounded-circle" style="width: 100px;height:100px" src="https://ui-avatars.com/api/?name={{ $data->username }}&color=7F9CF5&background=EBF4FF">
                            </div>
                            <div class="form-group mt-4">
                                <input type="file" id="profile" name="profilePhoto" class="file-upload-default"  onchange="imgPreview()">
                                <div class="input-group col-xs-12">
                                  <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                                  <span class="input-group-append">
                                    <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                  </span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="{{ $data->name }}">
                        </div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Username" value="{{ $data->username }}">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="{{ $data->email }}">
                        </div>
                        <button class="btn btn-primary" type="submit">Save</button>
                    </form>
                </div>
            </div>
        @else
            <div class="row mt-3 px-4 py-4" id="changePassword" style="background-color: #191c24;border-radius:0.5rem">
                <div class="col-md-6 ps-3 text-center">
                    <h4 class="align-center">Change Password</h4>
                </div>
                <div class="col-md-6">
                    <form action="{{ Route('adminChangePassword') }}" method="post">
                        @csrf
                        <input type="hidden" name="id" value="{{ $data->id }}">
                        <div class="form-group">
                            <label for="old_password">Old Password</label>
                            <input type="password" class="form-control" name="old_password" id="old_password" placeholder="Old Password" required>
                        </div>
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" class="form-control" name="new_password" id="new_password" placeholder="New Password" required>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required>
                        </div>
                        <button class="btn btn-primary" type="submit">Change</button>
                    </form>
                </div>
            </div>
        @endif
    </div>

<script>
    function imgPreview() {
        const image = document.querySelector("#profile");
        const imgPreview = document.querySelector(".img-preview");

        // imgPreview.style.display = 'block';

        const oFReader = new FileReader();
        oFReader.readAsDataURL(image.files[0]);

        oFReader.onload = function(oFREvent) {
            imgPreview.src = oFREvent.target.result;
        }
    }
</script>
@endsection