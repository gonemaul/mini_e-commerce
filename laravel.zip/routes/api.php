<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;

Route::get('/user', function (Request $request) {
    return $request->user()->email;
})->middleware('auth:sanctum');

// Route::middleware('guest')->groups(function (){
//     Route::post('/register', [AuthController::class, 'register_api']);
//     Route::post('/login', [AuthController::class, 'login_api']);

// });

// Route::post('/logout', [AuthController::class, 'logout_api']);
// Route::get('/user', [UserController::class, 'user_api']);
// Route::post('/user' , [UserController::class, 'update_user_api']);

// // Products Management
// Route::get('/products', [ProductController::class, 'products_api']);
// Route::get('/products/{id}', [ProductController::class, 'product_detail_api']);

// // Categories Management
// Route::get('/categories', [CategoryController::class, 'categories_api']);
// Route::get('/categories/{id}/products', [CategoryController::class, 'products_categories_api']);

// // Cart Management
// Route::post('/cart', [CartController::class, 'cart_api']);
// Route::post('/cart/{productId}', [CartController::class, 'update_cart_api']);
// Route::delete('/cart/{productId}', [CartController::class, 'delete_cart_api']);

// // Order Management
// Route::get('/orders', [OrderController::class, 'checkout_api']);
// Route::get('/orders/history', [OrderController::class, 'history_checkout_api']);