<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('showLogin');
    Route::post('/login', [AuthController::class, 'login'])->name('login');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('showRegister');
    Route::post('/register', [AuthController::class, 'register'])->name('register');
});

Route::middleware('auth')->group(function () {
    Route::get('/', function (){
        return view('home')->with([
            'title' => 'Dashboard'
        ]);
    })->name('home');

    // Admin Profile routes
    Route::get('/profile' ,[UserController::class, 'adminProfile'])->name('adminProfile');
    Route::post('/profile' ,[UserController::class, 'adminChangeProfile'])->name('adminChangeProfile');
    Route::get('/changePassword' ,[UserController::class, 'adminProfile'])->name('adminShowChangePassword');
    Route::post('/changePassword' ,[UserController::class, 'adminChangePassword'])->name('adminChangePassword');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    
    // Category Management
    Route::resource('/categories', CategoryController::class)->names([
        'index' => 'categories.index',
        'create' => 'categories.create',
        'store' => 'categories.store',
        'edit' => 'categories.edit',
        'update' => 'categories.update',
        'destroy' => 'categories.delete',
        'show' => 'categories.show',
    ]);

    // Product Management
    Route::resource('/products', ProductController::class)->names([
        'index' => 'products.index',
        'create' => 'products.create',
        'store' => 'products.store',
        'edit' => 'products.edit',
        'update' => 'products.update',
        'destroy' => 'products.delete',
        'show' => 'products.show',
    ]);

    // User Management
    Route::get('/users', [UserController::class, 'listUsers'])->name('listUsers');

    // Order Management
    Route::resource('/orders', OrderController::class)->names([
        'index' => 'orders.index',
        'create' => 'orders.create',
        'store' => 'orders.store',
        'edit' => 'orders.edit',
        'update' => 'orders.update',
        'destroy' => 'orders.delete',
        'show' => 'orders.show',
    ]);
});