

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Users List</h4>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th class="text-center" style="font-weight:600;"> Profile </th>
                  <th class="text-center" style="font-weight:600;"> Name </th>
                  <th class="text-center" style="font-weight:600;"> Username </th>
                  <th class="text-center" style="font-weight:600;"> Email </th>
                  <th class="text-center" style="font-weight:600;"> Role </th>
                  <th class="text-center" style="font-weight:600;"> Status </th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                  <tr>
                    <?php if($item->profile_image): ?>
                      <td class="text-center"> <img src="<?php echo e(asset('storage/' . $item->profile_image)); ?>"> </td>
                    <?php else: ?>
                      <td class="text-center"> <img src="https://ui-avatars.com/api/?name=<?php echo e($item->username); ?>&color=7F9CF5&background=EBF4FF"> </td>
                    <?php endif; ?>
                    <td> <?php echo e($item->name); ?> </td> 
                    <td> <?php echo e($item->username); ?> </td> 
                    <td> <?php echo e($item->email); ?> </td>
                    <?php if($item->is_admin): ?>
                      <td class="text-center"> Administrator </td>
                    <?php else: ?>
                      <td class="text-center"> User </td>
                    <?php endif; ?>
                    <td class="text-center"> <label class="badge badge-success">Active</label> </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\mini_e-commerce\resources\views/users/index.blade.php ENDPATH**/ ?>