

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="p-4" style="background-color: #191c24;border-radius:0.5rem">
        <div class="title mb-5">
            <h4>Edit Category</h4>
        </div>
        <form action="/categories/<?php echo e($data->id); ?>" method="post">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
            <div class="form-group">
                <label for="name">Category Name</label>
                <input type="text" class="form-control" id="name" name="category_name" placeholder="Category Name" value="<?php echo e($data->category_name); ?>" required>
            </div>
            <button class="btn btn-primary" type="submit">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\mini_e-commerce\resources\views/categories/edit.blade.php ENDPATH**/ ?>