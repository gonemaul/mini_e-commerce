

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="p-4" style="background-color: #191c24;border-radius:0.5rem">
            <div class="title mb-5">
                <h4>Create Category</h4>
            </div>
            <form action="/categories" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Category Name</label>
                    <input type="text" class="form-control" id="name" name="category_name" placeholder="Category Name" required>
                </div>
                <button class="btn btn-primary" type="submit">Save</button>
                <a href="<?php echo e(Route('categories.index')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\mini_e-commerce\resources\views/categories/create.blade.php ENDPATH**/ ?>